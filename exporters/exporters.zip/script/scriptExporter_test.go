package script

import "testing"

func TestParse(t *testing.T) {
	// content, err := os.ReadFile("D:\\tools\\Golang\\workspace\\OneAgent\\OneAgent\\node_exporter\\temp.txt")
	// if err != nil {
	// 	fmt.Println("Error reading file:", err)
	// 	return
	// }
	// contentStr := string(content)
	// CreateMetrics(ParseTableData(contentStr, "\r\n"),
	// 	[]string{"ip", "mac", "expire", "type", "interface", "instance", "vlan"})
}
