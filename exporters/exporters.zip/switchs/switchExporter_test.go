package switchs

import (
	"testing"
)

func TestParse(t *testing.T) {
	t.Fail()
}
